 
<div class="logoslider-pager">
      <div class="logoslider-wrapper">
	  
        
      <div id="width-wrap">
  
		<div id="contai">
		
		 <div id="wrppr" class="wrppr"></div>
		 
		 <div class="stacked">       
            
			
			<?php foreach ($h2s as $h2): ?>
			<div class="sld">
		 <div class="logoslider-wrapper__container">
           
		   <a href="<?php echo $h2->linka; ?>" alt="<?php echo $h2->h2; ?>" class="logoslider-wrapper__container_logo-link">
		   <div class="logoslider-wrapper__container_logo">
		   
		   
		<img width="" height="" class="logoslider-wrapper__container_logo-image-img" src="../images/<?php echo $h2->name_image;?>" 
		alt="<?php echo $h2->name_image; ?>" title="<?php echo $h2->name_image; ?>">
		 </div></a>
		
		 
		
		  </div>
		  </div>
	
       
	<?php endforeach; ?>
			
			
           
            </div>
		
		</div>
		
		
		</div>
 
		<div id="forlink">
		
		</div>
		
			
         
          
        </div>
      </div>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
<script type="text/javascript">

//инициализируется это из page.tpl.php	
//window.onload = function() {
//     clear(); 

//    aeimg();
//}
//window.onresize = function() {
//     clear(); 
//    aeimg();
//}


  
 
 


 function aeimg () {
 
 



    var asasa = window.getComputedStyle(document.querySelector('#width-wrap'), "");    // Создаем экземпляр объекта типа CSSStyleDeclaration для ссылки с идентификатором width-wrap
   
    var mstrwidth = parseInt(asasa.getPropertyValue("width")); // Полуаем значение свойства "ширина" для ссылки с помощью метода getPropertyValue, parseInt - преобразует пикселы в число
  
  
	var cntr = 0; //количество блоков зависит от ширины экрана
	
	if ( mstrwidth < 400) {cntr = 1;}
	if ( mstrwidth < 700) {cntr = 3;}
	if ( mstrwidth > 700) {cntr = 4;}
	if ( mstrwidth > 1000) {cntr = 5;}
	if ( mstrwidth > 1200) {cntr = 6;}
	if ( mstrwidth > 1400) {cntr = 8;}
	if ( mstrwidth > 1600) {cntr = 10;}
	
	 
			var contwidth = (mstrwidth / cntr)-1;    // ширина самих слайдов  
 	
	// добавляем новую ширину для блоков
		var oss = document.getElementsByClassName('sld'); 
		for (var i = 0; i < oss.length; i++) {
		oss[i].style.width = contwidth + "px";
		};
	
 //задаем блокам высоту =1/6 высоты экрана
			 var hgt = parseInt(document.documentElement.clientHeight)/5;
			 var imgcn = document.getElementsByClassName ('logoslider-wrapper__container_logo');
			 
			 for (var was = 0; was < imgcn.length; was++)
			 {imgcn[was].style.height = hgt + "px";};
				 
			 
			 
				//делаем искусственный justify
			 var mrgn =   (Math.ceil(((mstrwidth - (contwidth*(cntr-1)))/2)/(cntr-1)))-1;
			 
			

 // начинаем фасовать
var dv = document.getElementById('wrppr');
var cntai = document.getElementById('contai');
var divs = document.getElementsByClassName('sld');  
var slidnav = document.getElementById('forlink');  

	 
//вычисляем, сколько всего блоков
var cntwr = Math.floor(divs.length / cntr);
//получаем, по сколько в итоге выводить
var cntr2 = cntwr;


			 
			 
//цикл создания контейнеров и расфасовки по контейнерам объектов
				for (var k = 0; k < cntwr; k++)
 	
{
				//создаем контейнеры в #wrppr
				var d1v = document.createElement('div');
				dv.appendChild(d1v);
				d1v.setAttribute('class', 'csra');
				d1v.setAttribute('id', 'sl' + [k]);
				d1v.style.width = mstrwidth + 'px';
		 
	 		
				//создаем якоря
				var d3v = document.createElement('span');
				d1v.appendChild(d3v);
				d3v.setAttribute('class', 'dadada');
				d3v.setAttribute('id', "sld" + [k]);
				
				
				//создаем ссылки на блоки
				var d2v = document.createElement('a');
				slidnav.appendChild(d2v);
				d2v.setAttribute('class', 'roundlink');
				d2v.setAttribute('href',"#sld" + [k]);
				d2v.setAttribute('id',"sl" + [k]);
				d2v.setAttribute('onclick',"sl(this);");
				 
			
			//старое и новое положение объектов:
			var instack  = document.querySelectorAll('.stacked > .sld');
			var newstack = document.querySelectorAll('.csr > .sld');


			//начинаем расфасовку			
				if (newstack.length < cntr) {
		 // находим все sld и засовываем в .CSR
	                        for(var ci = 0 ; ci < cntr-1; ci++)
				{ 
			
			instack[ci].style.marginLeft = mrgn + 'px';
				instack[ci].style.marginRight = mrgn + 'px';
		 
			d1v.appendChild(instack[ci]);}
			
			}
				
			
 	
	
}

 
//ставим по умолчанию первому кружочку зеленый
var fst =  document.getElementById('forlink').firstElementChild;
fst.style.background = '#63C0BD';
     
};




 
	function sl (element) {
	
var sl = element;
var style = window.getComputedStyle(sl,"");
sl.style.background = (style.background == '#63C0BD')?'#575656':'#63C0BD';	 
 

 
 var fs2 = document.getElementsByClassName('csra');  
	 
 //выключатель цвета активного элемента
 var othr = document.getElementsByClassName('roundlink');
 for (var r=0; r < othr.length; r++) {
	 
	  if  (othr[r].id != sl.id) {
		  
		  var stle = window.getComputedStyle(othr[r],"");
			othr[r].style.background = '#575656';	
		  
 }};
 
 //добавляем анимацию появления логотипов
 	for (var chch = 0; chch < fs2.length; chch++) {
   	
	if (fs2[chch].id == sl.id) {fs2[chch].setAttribute("class",  "csra activea");}
					
					else {fs2[chch].setAttribute("class",  "csra");};
	 	
};

 
 
 
};
 
 



//фиксим скроллер

 window.onscroll = function() {
  var scrolled = window.pageYOffset || document.documentElement.scrollTop;
 
								var gagag = document.getElementById('wrppr');
 var objjj = gagag.getBoundingClientRect().top + window.scrollY;
 
 var nana = objjj - scrolled;
  
var nanaa = document.querySelectorAll('.dadada');

 for (var dd = 0; dd < nanaa.length; dd++)
 	{nanaa[dd].style.top = '-' + nana + 'px';}
 
}


//чистим при ресайзе
 
function clear () {

	var fsta = document.querySelectorAll('.sld');  
   	var cntneeer = document.querySelector('.stacked');  
	  
		//переносим sld обратно в базовое хранилище
 for (var g = 0; g < fsta.length; g++)
 	{cntneeer.appendChild(fsta[g]);}

//удаляем созданные контейнеры и ссылки
document.getElementById('wrppr').innerHTML = "";
document.getElementById('forlink').innerHTML = "";

 
   
};



</script>

	 
 
		
		
		<script type="text/javascript">
	 
 
		 
		 
		 
 function sharmanka1 () {
		
	 
//	setInterval(leffft, 3200);
  };
 
  
 
		
		</script>
	  
	  
	  
 
  