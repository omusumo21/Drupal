 

<div class="features1-container">
<div class="features1-wrapper">
	<?php foreach ($h2s as $h2): ?>
		 <div class="features1-wrapper__container">
           
		   
		   <div class="features1-wrapper__container_image" >
		<img class="features1-wrapper__container_image-img" src="../images/<?php echo $h2->name_image; ?>" 
		alt="<?php echo $h2->name_image; ?>" title="<?php echo $h2->name_image; ?>" style="max-height:<?php echo $tua;?>px!important;"  >
		 </div>
		
			<div class="fea1">
		<div class="features1-wrapper__container_title">
		 
				  <h3 class="features1-wrapper__container_titlediv-link-h3"><?php echo $h2->h2; ?></h3>
		   
		  </div>
		  
		  
		  <div class="features1-wrapper__container_text">
		   <p class="features1-wrapper__container_text_p"><?php echo $h2->text; ?></p>
		   </div>
		   </div>
		   
		   <div class="features1-wrapper__container_link">
				  <a href="<?php echo $h2->linka; ?>" class="features1-wrapper__container_linka" alt="<?php echo $h2->linkaname; ?>">
				  <div class="features1-wrapper__container_linka-btn"><?php echo $h2->linkaname; ?></div></a>

		
		  </div>
		  
		  
		  </div>
	     
	<?php endforeach; ?>
</div> 
</div> 

<script type="text/javascript">
function fea1 () { var mainDivs1 = document.getElementsByClassName("fea1");
 	      var maxHe = 0;
 	      for (var i = 0; i < mainDivs1.length; ++i) {
 						if (maxHe < mainDivs1[i].clientHeight) {
								maxHe = mainDivs1[i].clientHeight;
									} }
 
	      for (var i = 0; i < mainDivs1.length; ++i) {
							mainDivs1[i].style.height = maxHe + "px";
							}
}
  </script>
