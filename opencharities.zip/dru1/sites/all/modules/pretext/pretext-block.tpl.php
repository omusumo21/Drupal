<div class="pretext-pager">
	<?php foreach ($h2s as $h2): ?>
		
          
		  
		  
		   <div class="pretext-wrapper__container-textpart">
		   <div class="pretext-wrapper__container-textpart_title">
		 
				  <h2 class="pretext-wrapper__container-textpart_title_h2"><?php echo $h2->h2; ?></h2>
		    </div>
		   
		   
		  <div class="pretext-wrapper__container-textpart_text">
		 
				  <p class="pretext-wrapper__container-textpart_text-p"><?php echo $h2->text; ?></p>
		    </div>
		    </div>
		
	<?php endforeach; ?>
</div> 
