
<div class="sm-link-block">

<ul class="sm-link-block__menu">
	<?php foreach ($h2s as $h2):?>
		         
		<li class="sm-link-block__menu_li">
		<a href="<?php echo $h2->linka;?>" title="<?php echo $h2->text;?>">
		<i class="fa <?php echo $h2->h2;?> material-icons green"></i></a></li>
	         
	<?php endforeach; ?>
</ul>	
	

</div>