
 
  
          <div class="blogslider" >
        <div id="width-wrapper-viewport">
        <div id="container" class="container">
            
			 
            
			
    <?php
     	 
// подключаем таблицу с заголовками
    $query = db_select('node', 'a');
	$query->condition('a.type', 'article', '=');
    $query->fields('a', array( 'nid',  'title', 'changed'));
	$query->orderby('a.nid');
	$titleanddate=$query->execute();
	 
 // засовываем заголовок и дату в свой массив
while($rez=$titleanddate->fetchAssoc()){
$new_mas1[] = $rez;
  }
 
 //подключаем таблицу с текстами
	$query = db_select('field_data_body', 'b');
	$query->condition('b.bundle', 'article', '=');
    $query->fields('b', array('entity_id', 'body_value'));
	$query->orderby('b.entity_id');
	$ref=$query->execute();
  
 // засовываем ссыль и текст в свой массив
  	 while($reo=$ref->fetchAssoc()){
	
			$new_mas2[] = $reo; 
									}
     
// склеиваем массивы
$result = [];
foreach ($new_mas1 as $k => $v) {
    $result[$k] = array_merge($v, $new_mas2[$k]);
}


//print_r($result);
   $reversed = array_reverse($result);
  
  //выводим в шаблоне
  foreach ($reversed as $chucha) {
	  
//	  $i++;
	  //сокращаем до 12 последних 
//if($i >12) break;
	

	
	?>
	
	<div  class="slide">
	<div class="blogslider-wrapper ">
	
	<div class="blogslider-wrapper__title">
	<a href="<?php echo $chucha['entity_id']; //ссылка на стр события?> " class="blogslider-wrapper__title_a">
	<h3 class="blogslider-wrapper__title_h3"><?php  echo $chucha['title']; //заголовок?></h3></a> 
	</div>
	
	<div class="blogslider-wrapper__description"><p class="blogslider-wrapper__description_p">
	<?php
 //сокращаем текст до 300 символов
	$short = substr($chucha['body_value'], 0, 150);
	echo $short;
	?>...</p></div>
	
	<div class="blogslider-wrapper__date"><p class="blogslider-wrapper__date_p">
	<?php  
	  //преобразовываем дату создания из таймштампа в нормальный вид
	  $zuzuzu = date('j F Y', $chucha['changed']); 
	   echo $zuzuzu; 
	     ?></p></div></div> </div> 		 		 
 <?php }?>
 
     
            
      
          </div>
		 	
          </div>
		  
		  	<span  id="btt" onclick="rigght ();" class="fa fa-angle-left material-icons green arrl" ></span>
		<span id="btt" onclick="lefft ();"  class="fa fa-angle-right material-icons green arrr"></span>
          </div>
          
 
		
		
		
	 
		
		
		
 	<script type="text/javascript">
	//инициализируется это из page.tpl.php	
//window.onload= aea; //также добавил загрузчик в page.tpl.php - чтобы инициализировать нормально
//window.onresize = aea;

 function aea () {
 
    var cs = window.getComputedStyle(document.querySelector('#width-wrapper-viewport'), "");    // Создаем экземпляр объекта типа CSSStyleDeclaration для ссылки с идентификатором width-wrapper-viewport
   
    var masterwidth = parseInt(cs.getPropertyValue("width")); // Полуаем значение свойства "ширина" для ссылки с помощью метода getPropertyValue, parseInt - преобразует пикселы в число
  
	var counter = 1; //количество блоков зависит от ширины экрана
	
	if ( masterwidth < 700) {counter = 1;}
	if ( masterwidth > 700) {counter = 3;}
	if ( masterwidth > 1000) {counter = 4;}
	if ( masterwidth > 1400) {counter = 6;}
	if ( masterwidth > 1600) {counter = 8;}
	
	 
	 	 var containterwidth = (masterwidth / counter) - 30;    // ширина самих слайдов - если по 4 слайда на стр
 	
	
		var obb = document.getElementsByClassName('slide'); // добавляем новый размер для блоков
		for (var i = 0; i < obb.length; i++) {
		obb[i].style.width = containterwidth + "px";
		};
		
		 
 //выравниваем блоки с текстом по высоте
	      var mainDivs = document.getElementsByClassName("blogslider-wrapper__description_p");
 	      var maxHeight = 0;
 	      for (var i = 0; i < mainDivs.length; ++i) {
 						if (maxHeight < mainDivs[i].clientHeight) {
								maxHeight = mainDivs[i].clientHeight;
									} }
 
	      for (var i = 0; i < mainDivs.length; ++i) {
							mainDivs[i].style.height = maxHeight + "px";
							}
 
	 
	  
}



</script>

	 
		<style>
.hidde {

	
 

}
		</style>
		<script type="text/javascript">
		
		 	function lefft (fECh, lECh) {
	  	
			var cooont = document.getElementById('container');
	   var uha = window.getComputedStyle(document.querySelector('.slide'), "");   
       var ahu = parseInt(uha.getPropertyValue("width"));  
 
			var fECh = document.getElementById('container').firstElementChild;
			var lECh= document.getElementById('container').lastElementChild;
			var parent = lECh.parentNode;
			var next = lECh.nextSibling;

			
var start = Date.now();	 		
cooont.style.paddingLeft =  0 +'px';	
 
var timer = setInterval(function() {
	 var timePassed = Date.now() - start;
	
	
  if ( timePassed >= ahu) {clearInterval(timer);return;}
 draw(timePassed);
 
}, 12);			
	

function draw(timePassed) {
cooont.style.right = timePassed  + 'px';}	
			
			
			//собственно спустя 2 сек перемещаем объект и возвращаем на место марджина
  var timerId = setTimeout(  function slddd () { 

   cooont.style.right = 0 + 'px';
 
  if (next) {
    return parent.insertBefore(fECh, next);
  } else {
    return parent.appendChild(fECh);
  }}, ahu);
     
};
		
		 
		 
		 
	function sharmanka2 () {setInterval(lefft, 8000);};
	  
	  
	  
	  
	  
	  
	  
		function rigght () {
		
		var rcooont = document.getElementById('container');
	   var ruha = window.getComputedStyle(document.querySelector('.slide'), "");   
       var rahu = parseInt(ruha.getPropertyValue("width"));  
	   
			var rigghht = document.getElementById('container');
			var rFCh = rigghht.firstElementChild;
			var rLCh = rigghht.lastElementChild;
			
			
		rcooont.style.right =  rahu + 'px';
		rigghht.insertBefore(rLCh, rFCh);
		
		
	  var rstart = Date.now();
		var rtimer = setInterval(function() {
			var rtimePassed = Date.now() - rstart;
			
			
			  if ( rtimePassed >= rahu) {clearInterval(rtimer);return;}
 rdraw(rtimePassed);
 
}, 12);			
	

function rdraw(rtimePassed) {
rcooont.style.paddingLeft =  rtimePassed + 30 +'px';

setTimeout(  function sssd () {rcooont.style.paddingLeft =  0 +'px';}, rahu);

}	
			
		
			
		
		};
		
		</script>
  
  
   
		
	 
 
		





