


<div class="features2-wrapper">
	<?php foreach ($h2s as $h2): ?>
		 <div class="features2-wrapper__container">
           
		   
		   <div class="features2-wrapper__container_imagediv">
		<img class="features2-wrapper__container_imagediv-img" src="<?php path_to_theme().?> /images/<?php echo $h2->name_image; ?>" 
		alt="<?php echo $h2->name_image; ?>" title="<?php echo $h2->name_image; ?>">
		 </div>
		
		
		<div class="features2-wrapper__container_titlediv">
		 
				  <a href="<?php echo $h2->linka; ?>" class="features2-wrapper__container_titlediv-link" alt="<?php echo $h2->linkaname; ?>">
				  <h3 class="features2-wrapper__container_titlediv-link-h3"><?php echo $h2->h2; ?></h3></a>
		   
		  </div>
		  
		  
		  <div class="features2-wrapper__container_text">
		   <p class="features2-wrapper__container_text_p"><?php echo $h2->text; ?></p>
		   </div>
		
		  </div>
	
       
	<?php endforeach; ?>
</div> 
