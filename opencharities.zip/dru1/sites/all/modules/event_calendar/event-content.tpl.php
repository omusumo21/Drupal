
<?php
     
 
//ищем дату
$now = time();
$past_dates = [];

foreach ($dates as $linka) {
    $timestamp = strtotime($linka->linka);
   
    if ($timestamp > $now) {
  		$past_dates[] = $timestamp;
  	}
}

$result = 'unknown';

if (count($past_dates) > 0) {
   
   $fufufuf = date('Y-m-d', min($past_dates)); 
    
  //фильтруем из БД по найденной дате
    $query = db_select('event', 't');
	$query->condition('t.linka', $fufufuf, '=');
    $query->fields('t', array('id', 'name_event', 'date', 'linka'));
	$query->orderby('t.linka');
	$res=$query->execute();
	
	
	
	//выводим в шаблоне
 
while($rec=$res->fetchAssoc()){
	
	//преобразуем дату в приятный вид
	
	$dddate = strtotime($rec['linka']);
	$ddate = date('jS F Y', $dddate);
	
	?>
	
	
	
	
	<div class="event-wrapper">
	
	<div class="event-wrapper__left-element">
	
	<div class="event-wrapper__left-element-top">
	
	<div class="event-wrapper__left-element-top_link">
	<a href="<?php echo $rec['links'];?>" class="event-wrapper__left-element-top_link-a">Next event:</a>
	</div>
	
	<div class="event-wrapper__left-element-top_date">
	<?php echo $ddate;?>
	</div>
	
	<div class="event-wrapper__left-element-top_info">
	<?php echo $rec['date'];?>
	</div>
	
	</div>
	
	
	
	<div class="event-wrapper__left-element-bottom">
	<?php echo $rec['name_event'];?>
	</div>
	
	</div>
	
	<div class="event-wrapper__right-element">
	<span class="event-wrapper__right-element-button" onclick="fpo ();">
	<div class="event-wrapper__right-element-button_modificator">Register</div>
	</span>
	</div>
	
	
	<style>
	#forma {display:none;}
	</style>
	
	
	<div id="forma" class="event__form">
	
<form action="send.php" method="post">
<p>Ваше имя:<br /><input type="text" name="your_name" /></p>
<p>E-mail:<br /><input type="text" name="email" /></p>
<p>Тема:<br /><input type="text" name="tema" value=" <?php echo $rec['name_event'];?>" /></p>
<p>Сообщение:<br />
<textarea name="message" type="text" rows="5" cols="45"> </textarea></p>

<div class="event__form-button"><input type="submit" value="Отправить"></div>

</form>

	</div>
	
	
</div>






	<script>
	
	function fpo () {
	
var regform = document.getElementById("forma");
var style = window.getComputedStyle(regform,"");
regform.style.display = (style.display == 'none')?'block':'none';	 
	 
 
}
 	</script>
	
	
	
	<?php	
}
} ?>
	
	
	
	

