
<?php
     
 
//ищем дату
$now = time();
$past_dates = [];

foreach ($dates as $linka) {
    $timestamp = strtotime($linka->linka);
   
    if ($timestamp > $now) {
  		$past_dates[] = $timestamp;
  	}
}

$result = 'unknown';

if (count($past_dates) > 0) {
   
   $fufufuf = date('Y-m-d', min($past_dates)); 
    
  //фильтруем из БД по найденной дате
    $query = db_select('event', 't');
	$query->condition('t.linka', $fufufuf, '=');
    $query->fields('t', array('id', 'name_event', 'links', 'date', 'linka'));
	$query->orderby('t.linka');
	$res=$query->execute();
	
	
	
	//выводим в шаблоне
 
while($rec=$res->fetchAssoc()){
	
	//преобразуем дату в приятный вид
	
	$dddate = strtotime($rec['linka']);
	$ddate1 = date('j', $dddate);
	$ddate2 = date('S', $dddate);
	$ddate3 = date('F', $dddate);
	$ddate4 = date('Y', $dddate);
	
	?>
	
	
	
	
	<div class="event">
	
	<div class="event-wrapper">
	
	<div class="event-wrapper__left-element">
	
	<div class="event-wrapper__left-element-top">
	
	<div class="event-wrapper__left-element-top_link">
	<a href="<?php echo $rec['links'];?>" class="event-wrapper__left-element-top_link-a">Next Event:</a>
	</div>
	
	<div class="event-wrapper__left-element-top_date">
	<?php echo $ddate1;?><sup><?php echo $ddate2;?></sup>&nbsp;<?php echo $ddate3;?>&nbsp;<?php echo $ddate4;?>
	</div>
	
	<div class="event-wrapper__left-element-top_info">
	<?php echo $rec['date'];?>
	</div>
	
	</div>
	
	
	
	<div class="event-wrapper__left-element-bottom">
	<?php echo $rec['name_event'];?>
	</div>
	
	</div>
	
	<div class="event-wrapper__right-element">
	<span class="event-wrapper__right-element-button" onclick="fpo ();">
	<div class="event-wrapper__right-element-button_modificator">REGISTER</div>
	</span>
	</div>
	
	
	 
	
	
	
	
</div>
</div>






	<script>
	
	function fpo () {
	
var regform = document.getElementById("forma");
var style = window.getComputedStyle(regform,"");
regform.style.display = (style.display == 'none')?'block':'none';	
 
regform.setAttribute ('class', 'fade')?' ':'fade';
 
  
 //если открыта форма входа - выключаем ее
var loginform = document.getElementById('block-user-login');
var style = window.getComputedStyle(loginform,"");
loginform.style.display = (style.display == 'block')?'none':'none';	
}
 	</script>
	
	
	
	<?php	
}
} ?>
	
	
	
	

