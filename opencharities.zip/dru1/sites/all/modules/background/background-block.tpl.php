

<?php     

$wiiidth = [];
$heiggght = [];
 
foreach ($h2s as $h2) {
	
//получаем картинки
 $tng = $_SERVER['DOCUMENT_ROOT'].'/images/'.$h2->name_image;

 //получаем размеры картинок
list($width, $height, $type, $attr) = getimagesize($tng);
 
 $heiggght[] = $height;
 $wiiidth[] = $width;

}

//выбираем самую маленькую по высоте
$dadaw=min ($wiiidth);
$dadah=min ($height);


 

?>


<div class="background-pager">
	<?php foreach ($h2s as $h2): ?>
		
          
		  <div class="background-wrapper__container_image" id="imagawr">
		<img class="background-wrapper__container_image-img" src="../images/<?php echo $h2->name_image;?>" 
		alt="<?php echo $h2->name_image; ?>" title="<?php echo $h2->name_image; ?>" id="imaga" style="width:<?php echo $dadaw; ?> ; height:<?php echo $dadah; ?>;">
		 </div>
		  
		   
	 
	<?php endforeach; ?>
</div> 



<script>


function backgrounder () {

var imaga = document.getElementById('imaga');
var imagawr = document.getElementById('imagawr');

   var bck1 = window.getComputedStyle(document.querySelector('.background-wrapper__container_image-img'), "");    
      var bck1w = parseInt(bck1.getPropertyValue("width"));
      var bck1h = parseInt(bck1.getPropertyValue("height"));
	 
	 
		var bck2 = parseInt(document.documentElement.clientHeight);    
		var bck3 = parseInt(document.documentElement.clientWidth);    
 	
			 
			 
			var otn =  bck1w / bck1h; // отношение ширины к высоте
			 
			 imaga.style.height =  bck2 + 'px '; // принудительно высота экрана
			 
			var iwi = bck2 * otn; // получили ширину
			 
			  imaga.style.width =  iwi + 'px '; // задали ширину
			  
			  var otstup = Math.ceil((iwi - bck3)/2); //получили отступ
			  
			   imaga.style.marginLeft = '-' + otstup + 'px'; // задали отступ
		
			
			
};

</script>